# BudgetBite - Recipe to Grocery List App

## 🚀 How to Deploy (No Coding Required!)

### Step 1: Create a Vercel Account (Free)
1. Go to https://vercel.com
2. Click "Sign Up"
3. Sign up with your email or GitHub account
4. Verify your email if needed

### Step 2: Deploy Your App
1. Go to https://vercel.com/new
2. Look for "Import Third-Party Git Repository" or just drag & drop
3. **Easier method:** 
   - Go to https://vercel.com/dashboard
   - Click "Add New..." → "Project"
   - Choose "Upload" or drag this entire folder

### Step 3: That's It!
After deploying, you'll get a URL like:
`https://budgetbite-xxxxx.vercel.app`

Your app now works with REAL Kroger prices!

---

## 📁 What's in This Folder

- `index.html` - Your BudgetBite app
- `api/kroger.js` - Backend that talks to Kroger API
- `vercel.json` - Tells Vercel how to run the app
- `README.md` - This file

---

## 🔑 API Keys (Already Configured)

- **Spoonacular** (recipe parsing): Active
- **Kroger** (real product prices): Active

---

## 💡 Features

✅ Paste any recipe URL → Get ingredient list
✅ Real Kroger product prices
✅ Save shopping lists
✅ Shopping mode with checkboxes
✅ Beautiful mobile-friendly design

---

## 🆘 Need Help?

If something doesn't work after deploying:
1. Check that all 3 files are uploaded
2. Wait 1-2 minutes for deployment to complete
3. Try refreshing the page

Enjoy your app! 🛒🍳
