// Kroger API Proxy - handles authentication and product search
// This runs on Vercel's servers, bypassing CORS issues

const KROGER_CLIENT_ID = 'budgetbite-omar-bbc91h50';
const KROGER_CLIENT_SECRET = '4N73cgZLOb2-OoTZ4-Gx9hSWLV22T9hCXoIDnWwa';

let cachedToken = null;
let tokenExpiry = null;

// Get access token from Kroger
async function getToken() {
    if (cachedToken && tokenExpiry && Date.now() < tokenExpiry) {
        return cachedToken;
    }

    const credentials = Buffer.from(`${KROGER_CLIENT_ID}:${KROGER_CLIENT_SECRET}`).toString('base64');
    
    const response = await fetch('https://api.kroger.com/v1/connect/oauth2/token', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
            'Authorization': `Basic ${credentials}`
        },
        body: 'grant_type=client_credentials&scope=product.compact'
    });

    if (!response.ok) {
        throw new Error('Failed to get Kroger token');
    }

    const data = await response.json();
    cachedToken = data.access_token;
    tokenExpiry = Date.now() + ((data.expires_in - 300) * 1000);
    
    return cachedToken;
}

// Main handler
export default async function handler(req, res) {
    // Enable CORS
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

    if (req.method === 'OPTIONS') {
        return res.status(200).end();
    }

    const { action, term, locationId, zipCode } = req.query;

    try {
        const token = await getToken();

        // Search for products
        if (action === 'search' && term) {
            let url = `https://api.kroger.com/v1/products?filter.term=${encodeURIComponent(term)}&filter.limit=1`;
            if (locationId) {
                url += `&filter.locationId=${locationId}`;
            }

            const response = await fetch(url, {
                headers: {
                    'Authorization': `Bearer ${token}`,
                    'Accept': 'application/json'
                }
            });

            if (!response.ok) {
                return res.status(response.status).json({ error: 'Kroger API error' });
            }

            const data = await response.json();
            return res.status(200).json(data);
        }

        // Search for stores
        if (action === 'locations' && zipCode) {
            const response = await fetch(
                `https://api.kroger.com/v1/locations?filter.zipCode.near=${zipCode}&filter.limit=5`,
                {
                    headers: {
                        'Authorization': `Bearer ${token}`,
                        'Accept': 'application/json'
                    }
                }
            );

            if (!response.ok) {
                return res.status(response.status).json({ error: 'Kroger API error' });
            }

            const data = await response.json();
            return res.status(200).json(data);
        }

        // Test endpoint
        if (action === 'test') {
            return res.status(200).json({ success: true, message: 'Kroger API proxy is working!' });
        }

        return res.status(400).json({ error: 'Invalid action. Use ?action=search&term=milk or ?action=locations&zipCode=45202' });

    } catch (error) {
        console.error('Kroger API error:', error);
        return res.status(500).json({ error: error.message });
    }
}
